let formulario = document.login
console.log(formulario)
formulario.addEventListener('submit', async (e)=>{
    e.preventDefault()
    let data = {
        correo: formulario.correo.value,
        pass: formulario.pass.value
    }    
    console.log(JSON.stringify(data))
    let res = await fetch("http://localhost:3000/login", {
        method: "POST",
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data)
    })
    let resData = await res.json()
    if (resData.respuesta) {
        window.location.href = "/home.html"
    }else {
        alert("Contraseña incorrecta")
    }
})
