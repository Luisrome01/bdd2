let formulario = document.regis

formulario.addEventListener('submit', async(e)=>{
    e.preventDefault()
    if (formulario.pass.value == formulario.pass_repeated.value) {
     let data = {
        nombre: formulario.nombre.value,
        correo: formulario.email.value,
        pass: formulario.pass.value
    }     
      console.log(JSON.stringify(data))

      let res = await fetch("http://localhost:3000/register", {
        method: "POST",
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data)
    })

let resData = await res.json()
if(resData.respuesta){
    alert("Usuario registrado correctamente")

}
    }else{alert("las contraseñas no coinciden")}
    
})