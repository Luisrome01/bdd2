const express = require('express')
const cors = require('cors')
const app = express();

// formatos aceptados
app.use(express.json());
app.use(express.urlencoded({extended:false}));
app.use(cors())

// rutas 
app.use(require('./routes/index'))



const puerto = 3000;
app.listen(puerto)

console.log('Server activado')