const {Router} = require('express');
const router = Router();

const { 
    getPlatos,
    createPlato,
    getPlatoByID,
    delPlatos,
    getPlatosBySales
} = require('../funciones/Platos')

const {
    getFactura,
    createFactura,
    getFacturaByQuery,
    delFactura
} = require('../funciones/Facturas')

const { 
getMesas,
UpdMesas,
createMesa,
delMesa
} = require('../funciones/Mesas')

const{
    getMesero,
    createMesero,
    delmesero, 
    getMeseroByID,
    Updmesero
    } = require("../funciones/Mesero")

const {
registerUser,
logUser
} = require("../funciones/Usuarios")
const {
    getSupervisor,
    createSupervisor,
    delsupervisor, 
    getSupervisorByID,
    UpdSupervisor
    } = require("../funciones/Supervisor")

const {
    getClientes,
    createClientes,
    getClienteByID,
    delcliente
    } = require("../funciones/Clientes")

// GET POST PUT DELETE
router.get('/platos', getPlatos)
router.get('/platos/:id', getPlatoByID)
router.post('/platos', createPlato)
router.delete('/platos', delPlatos)
router.get('/platosVentas', getPlatosBySales)

router.get('/factura', getFactura)
router.post('/factura', createFactura)
router.get('/facturaQ', getFacturaByQuery)
router.delete('/factura/:Nro', delFactura)

router.get('/mesas', getMesas)
router.put('/mesas', UpdMesas)
router.post('/mesas', createMesa)
router.delete('/mesa', delMesa)

router.get('/mesero', getMesero)
router.put('/mesero', Updmesero)
router.post('/mesero', createMesero)
router.delete('/mesero', delmesero)
router.get('/mesero/:id', getMeseroByID)

router.get('/supervisor', getSupervisor)
router.post('/supervisor', createSupervisor)
router.delete('/supervisor', delsupervisor)
router.get('/supervisor/:id', getSupervisorByID)
router.put('/supervisor', UpdSupervisor)

router.get('/clientes', getClientes)
router.post('/clientes', createClientes)
router.delete('/clientes', delcliente)
router.get('/clientes/:id', getClienteByID)

router.post('/register', registerUser)
router.post('/login', logUser)
module.exports = router;