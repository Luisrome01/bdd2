const pool  = require('./getPool')


const getFactura = async (req, res) =>{
    const response = await pool.query( `
    select f.nro_factura, c.nombres || ' ' || c.apellidos as cliente, f.nro_mesa, m.nombres || ' ' || m.apellidos as mesero, s.nombres || ' ' || s.apellidos as supervisor, f.fecha from 
    factura as f inner join cliente as c 
    on f.id_cliente = c.id_cliente 
    inner join mesero as m 
    on f.id_mesero = m.id_mesero 
    inner join supervisor as s
    on f.id_supervisor = s.id_supervisor
    `);

    const response2 = await pool.query(`
    select pf.nro_factura, p.nombre as plato, pf.cantidad from 
    platos as p inner join plato_factura as pf
    on p.id_platos = pf.id_platos
    `)

   response.rows.forEach(factura => {
       factura.platos = [] 
       response2.rows.forEach(platos => {
           if (platos.nro_factura == factura.nro_factura) {
               factura.platos.push({
                nombre: platos.plato,
                cantidad: platos.cantidad
                
               })
           }
       });
   });
    
    res.send(response.rows)
}

const createFactura = async (req, res) =>{
const {cliente, mesa, mesero, supervisor, fecha} = req.body
const response = await pool.query("insert into factura (id_cliente, nro_mesa, id_mesero, id_supervisor, fecha) values ($1, $2, $3, $4, $5)", [cliente, mesa, mesero, supervisor, fecha])
res.send(response)
}

const getFacturaByQuery = async (req, res) =>{
let param 
let value

if (req.query.num) {
    param = "nro_factura"
    value = req.query.num
}else if (req.query.cliente){
    param = "c.nombres || ' ' || c.apellidos"
    value = `'` + req.query.cliente + `'`
}else if (req.query.mesero){
    param = "m.nombres || ' ' || m.apellidos"
    value = `'` + req.query.mesero + `'`
}else if (req.query.supervisor){
    param = "s.nombres || ' ' || s.apellidos"
    value = `'` + req.query.supervisor + `'`
}
    const response = await pool.query( `
    select f.nro_factura, c.nombres || ' ' || c.apellidos as cliente, f.nro_mesa, m.nombres || ' ' || m.apellidos as mesero, s.nombres || ' ' || s.apellidos as supervisor, f.fecha from 
    factura as f inner join cliente as c 
    on f.id_cliente = c.id_cliente 
    inner join mesero as m 
    on f.id_mesero = m.id_mesero 
    inner join supervisor as s
    on f.id_supervisor = s.id_supervisor where ${param} = ${value}
    `);

    const response2 = await pool.query(`
    select pf.nro_factura, p.nombre as plato, pf.cantidad from 
    platos as p inner join plato_factura as pf
    on p.id_platos = pf.id_platos
    `)

   response.rows.forEach(factura => {
       factura.platos = [] 
       response2.rows.forEach(platos => {
           if (platos.nro_factura == factura.nro_factura) {
               factura.platos.push({
                nombre: platos.plato,
                cantidad: platos.cantidad
                
               })
           }
       });
   });

    res.send(response.rows)
}

const delFactura = async (req, res) =>{

    const response = await pool.query(`delete from factura where nro_factura = ${req.params.Nro}`);
    res.send("realizada " + response)
}

module.exports = {
   getFactura, 
   createFactura,
   getFacturaByQuery,
   delFactura
}