const bcryptjs = require('bcryptjs')
const pool  = require('./getPool')


const registerUser = async (req, res) => {
    const {nombre, correo, pass} = req.body
    let password = await bcryptjs.hash(pass, 8)

    const response = await pool.query('insert into usuarios (correo, nombre, pass) values ($1, $2, $3)', [correo, nombre, password])
    res.json({respuesta: true})
}

const logUser = async (req, res) => {
    console.log(req.body)

    const {correo, pass } = req.body
    const response = await pool.query('select * from usuarios where correo = $1', [correo])
    let hash = response.rows[0].pass
    let boolean = await bcryptjs.compare(pass, hash)
if (boolean) {
        res.json({respuesta: true})
}else { res.json({respuesta: false})
    
}
}
module.exports = {
    registerUser,
    logUser
}


/*

Insert de prueba: 
{
  "nombre": "Pepe",
  "correo": "foo@foo.com",
  "pass": "12323123"
}

*/