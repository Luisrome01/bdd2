const pool  = require('./getPool')


const getMesero = async (req, res) =>{
    const response = await pool.query('select * from mesero');
    res.send(response.rows)
}

const createMesero = async (req, res) =>{
const {nombres, apellidos, edad, antiguedad} = req.body
const response = await pool.query("insert into mesero (nombres, apellidos, edad, antiguedad) values ($1, $2, $3, $4)", [nombres, apellidos, edad, antiguedad])
res.send(response)
}



const getMeseroByID = async (req, res) =>{

    const response = await pool.query(`select * from mesero where id_mesero = ${req.params.id}`);
    res.send(response.rows)
}

const delmesero = async (req, res) =>{

    const response = await pool.query(`delete from mesero where id_mesero = ${req.query.id}`);
    res.send(response.rows)
}

const Updmesero = async (req, res) => {
    
    let param
    let value
    if (req.query.edad) {
        param = 'edad'
        value = req.query.edad
    }else if (req.query.antiguedad) {
        param = 'antiguedad'
        value = req.query.antiguedad
    }
    const response = await pool.query (`
    update mesero set ${param} = ${value}
    where id_mesero = ${req.query.mesero}
    `)
    res.send(response.rows)
}


module.exports = {
getMesero,
createMesero,
delmesero, 
getMeseroByID,
Updmesero
}