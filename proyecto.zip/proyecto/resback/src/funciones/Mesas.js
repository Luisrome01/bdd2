const { put, param } = require('../routes');
const pool  = require('./getPool')
const getMesas = async (req, res) =>{
    const response = await pool.query('select * from mesa');
    res.send(response.rows)
}

const createMesa = async (req, res) =>{
    const {reservada, puestos} = req.body
    const response = await pool.query("insert into mesa (reservada, puestos) values ($1, $2)", [reservada, puestos])
    res.send(response)
    }
    
    const delMesa = async (req, res) =>{

        const response = await pool.query(`delete from mesa where nro_mesa = ${req.query.num}`);
        res.send(response.rows)
    }

const UpdMesas = async (req, res) => {
    
    let param
    let value
    if (req.query.reservada) {
        param = 'reservada'
        value = req.query.reservada
    }else if (req.query.puestos) {
        param = 'puestos'
        value = req.query.puestos
    }
    const response = await pool.query (`
    update mesa set ${param} = ${value}
    where nro_mesa = ${req.query.mesa}
    `)
    res.send(response.rows)
}

module.exports = {
    getMesas,
    UpdMesas,
    createMesa,
    delMesa
}