const pool  = require('./getPool')


const getClientes = async (req, res) =>{
    const response = await pool.query('select * from cliente');
    res.send(response.rows)
}

const createClientes = async (req, res) =>{
const {nombres, apellidos, direccion, telefono} = req.body
const response = await pool.query("insert into cliente (nombres, apellidos, direccion, telefono) values ($1, $2, $3, $4)", [nombres, apellidos, direccion, telefono])
res.send(response)
}



const getClienteByID = async (req, res) =>{

    const response = await pool.query(`select * from cliente where id_cliente = ${req.params.id}`);
    res.send(response.rows)
}

const delcliente = async (req, res) =>{

    const response = await pool.query(`delete from cliente where id_cliente = ${req.query.id}`);
    res.send(response.rows)
}



module.exports = {
getClientes,
createClientes,
getClienteByID,
delcliente
}
