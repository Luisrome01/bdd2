const pool  = require('./getPool')


const getSupervisor = async (req, res) =>{
    const response = await pool.query('select * from supervisor');
    res.send(response.rows)
}

const createSupervisor = async (req, res) =>{
const {nombres, apellidos, edad, antiguedad} = req.body
const response = await pool.query("insert into supervisor (nombres, apellidos, edad, antiguedad) values ($1, $2, $3, $4)", [nombres, apellidos, edad, antiguedad])
res.send(response)
}



const getSupervisorByID = async (req, res) =>{

    const response = await pool.query(`select * from supervisor where id_supervisor = ${req.params.id}`);
    res.send(response.rows)
}

const delsupervisor = async (req, res) =>{

    const response = await pool.query(`delete from supervisor where id_supervisor = ${req.query.id}`);
    res.send(response.rows)
}

const UpdSupervisor = async (req, res) => {
    
    let param
    let value
    if (req.query.edad) {
        param = 'edad'
        value = req.query.edad
    }else if (req.query.antiguedad) {
        param = 'antiguedad'
        value = req.query.antiguedad
    }
    const response = await pool.query (`
    update supervisor set ${param} = ${value}
    where id_supervisor = ${req.query.supervisor}
    `)
    res.send(response.rows)
}


module.exports = {
getSupervisor,
createSupervisor,
delsupervisor, 
getSupervisorByID,
UpdSupervisor
}