
const pool  = require('./getPool')

const getPlatos = async (req, res) =>{
    const response = await pool.query('select * from platos');
    res.send(response.rows)
}

const createPlato = async (req, res) =>{
const {nombre, precio} = req.body
const response = await pool.query("insert into platos (nombre, precio) values ($1, $2)", [nombre, precio])
res.send(response)
}

const getPlatosBySales = async (req, res) => {
    const response = await pool.query(`
    select p.id_platos, p.nombre, p.precio, v.ventas from
    (select id_platos, sum(cantidad) as ventas 
    from plato_factura group by id_platos) as v
    inner join platos as p 
    on v.id_platos = p.id_platos
    order by ventas desc
    `)
    res.send(response.rows)
}

const getPlatoByID = async (req, res) =>{

    const response = await pool.query(`select * from platos where id_platos = ${req.params.id}`);
    res.send(response.rows)
}

const delPlatos = async (req, res) =>{

    const response = await pool.query(`delete from platos where id_platos = ${req.query.id}`);
    res.send(response.rows)
}

module.exports = {
    getPlatos,
    createPlato,
    getPlatosBySales,
    getPlatoByID,
    delPlatos
}